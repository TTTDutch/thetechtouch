g++ -o Game ../src/client/main.cpp ../src/engine/subscribe.cpp ../src/engine/engine.cpp ../src/engine/menu.cpp -lGL -lGLEW -lsfml-graphics 
