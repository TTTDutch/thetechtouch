/*
 * =====================================================================================
 *
 *       Filename:  main.cpp
 *
 *    Description:  
 *
 *        Version:  1.0
 *        Created:  03/31/2011 11:29:02 PM
 *       Revision:  none
 *       Compiler:  gcc
 *
 *         Author:  Brent Ritzema (), thetechtouchdutch@gmail.com
 *        Company:  thetechtouch
 *
 * =====================================================================================
 */

#include <iostream>
#include "../engine/engine.h"

using namespace std;

bool yes = false;

void Draw();
void TestMenu();
void Input();

int main()
{
   engine->SetupWindow(600,600,8,"Game");
   engine->GetRenderSub()->AddSub(&TestMenu);
   engine->GetEventSub()->AddSub(&Input);
   engine->Update();
   return 0;
}

void Draw()
{
   sf::Image img_Man;
   img_Man.LoadFromFile("../media/Man.png");
   sf::Sprite spt_Man(img_Man);
   spt_Man.SetPosition(20,20);
   engine->GetWindow()->Draw(spt_Man);
}

void TestMenu()
{
   sf::Image img;
   img.LoadFromFile("../media/Man.png");
   Menu menu(400,400,20);
   menu.AddChoice(img, &Draw);
   engine->GetWindow()->Draw((*menu.GetChoice(0)->GetSprite()));
   if(yes == true)
   menu.CallFunc(0);
}

void Input()
{
   if(engine->GetEventHandler()->Type == sf::Event::KeyPressed)

      switch(engine->GetEventHandler()->Key.Code)
      {
         case sf::Key::Escape:
         engine->Exit();
         break;

         case sf::Key::Y:
         yes = true;
         break;

         default:
         break;
      }

}
